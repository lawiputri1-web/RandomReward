# Random Reward Command Aliases (Fabric)

Adds the exact commands `/rron` and `/rrof` to Minecraft Java 1.21.11, calling the bundled Random Reward functions `rr:on` and `rr:off`.

## Build
1. Upload the contents of this project to a GitHub repository.
2. Open **Actions** and run **Build Random Reward Mod** (or push to `main`).
3. Download `RandomRewardCommandAliases.jar` from the workflow artifact.
4. Install Fabric Loader for Minecraft Java 1.21.11 and place the JAR in `mods/`.

This is a Fabric mod, not a standalone datapack. Commands require permission level 2 (OP/cheats). The existing Random Reward function files are bundled in the mod.
