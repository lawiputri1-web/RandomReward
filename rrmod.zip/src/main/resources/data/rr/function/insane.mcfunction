execute store result score @s rr_item run random value 1..12
execute if score @s rr_item matches 1 run give @s minecraft:netherite_block 8
execute if score @s rr_item matches 2 run give @s minecraft:enchanted_golden_apple 16
execute if score @s rr_item matches 3 run give @s minecraft:netherite_ingot 32
execute if score @s rr_item matches 4 run give @s minecraft:splash_potion[minecraft:potion_contents={potion:"minecraft:weakness"}] 2
execute if score @s rr_item matches 5 run give @s minecraft:totem_of_undying 16
execute if score @s rr_item matches 6 run give @s minecraft:diamond_block 64
execute if score @s rr_item matches 7 run give @s minecraft:golden_apple 64
execute if score @s rr_item matches 8 run give @s minecraft:netherite_sword 1
execute if score @s rr_item matches 9 run give @s minecraft:netherite_chestplate 1
execute if score @s rr_item matches 10 run give @s minecraft:elytra 1
execute if score @s rr_item matches 11 run give @s minecraft:netherite_upgrade_smithing_template 1
execute if score @s rr_item matches 12 run give @s minecraft:silence_armor_trim_smithing_template 4
tellraw @s {"text":"[!!!] OP PARAH! Kamu mendapatkan hadiah langka!","color":"red","bold":true}
playsound minecraft:entity.player.levelup master @s ~ ~ ~ 1 1
