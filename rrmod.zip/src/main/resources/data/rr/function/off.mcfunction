scoreboard players set #enabled rr_enabled 0
tellraw @a {"text":"[Random Reward] MATI! Hadiah otomatis dihentikan.","color":"red","bold":true}

scoreboard objectives setdisplay sidebar
