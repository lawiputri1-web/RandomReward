scoreboard objectives add rr_enabled dummy
scoreboard objectives add rr_timer dummy
scoreboard objectives add rr_roll dummy
scoreboard objectives add rr_item dummy
scoreboard objectives add rron trigger

scoreboard players set #enabled rr_enabled 0
scoreboard players set Timer rr_timer 1200

tellraw @a {"text":"[Random Reward] Data Pack dimuat! Gunakan /trigger rron untuk aktifkan dan /function rr:off untuk mematikan.","color":"green"}
