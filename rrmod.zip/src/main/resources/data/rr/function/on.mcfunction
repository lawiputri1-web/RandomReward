scoreboard players set #enabled rr_enabled 1
scoreboard players set Timer rr_timer 1200
tellraw @a {"text":"[Random Reward] AKTIF! Hadiah pertama dalam 60 detik.","color":"green","bold":true}

scoreboard objectives setdisplay sidebar rr_timer
scoreboard objectives modify rr_timer displayname {"text":"⚡RANDOM REWARD SLAMET⚡","color":"green","bold":true}
