execute if score #enabled rr_enabled matches 1 run scoreboard players remove Timer rr_timer 1
execute if score #enabled rr_enabled matches 1 if score Timer rr_timer matches ..0 run function rr:reward

scoreboard players enable @a rron
execute as @a[scores={rron=1..}] run function rr:on
scoreboard players set @a[scores={rron=1..}] rron 0
