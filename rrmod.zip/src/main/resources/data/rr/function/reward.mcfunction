scoreboard players set Timer rr_timer 1200
execute as @a store result score @s rr_roll run random value 1..1000
execute as @a[scores={rr_roll=1..500}] run function rr:basic
execute as @a[scores={rr_roll=501..850}] run function rr:op
execute as @a[scores={rr_roll=851..1000}] run function rr:insane
