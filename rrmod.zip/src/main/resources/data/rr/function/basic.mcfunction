execute store result score @s rr_item run random value 1..14
execute if score @s rr_item matches 1 run give @s minecraft:splash_potion[minecraft:potion_contents={potion:"minecraft:weakness"}] 2
execute if score @s rr_item matches 2 run give @s minecraft:cooked_beef 16
execute if score @s rr_item matches 3 run give @s minecraft:iron_ingot 16
execute if score @s rr_item matches 4 run give @s minecraft:gold_ingot 8
execute if score @s rr_item matches 5 run give @s minecraft:coal 32
execute if score @s rr_item matches 6 run give @s minecraft:emerald 4
execute if score @s rr_item matches 7 run give @s minecraft:arrow 32
execute if score @s rr_item matches 8 run give @s minecraft:golden_carrot 8
execute if score @s rr_item matches 9 run give @s minecraft:stone 512
execute if score @s rr_item matches 10 run give @s minecraft:netherrack 32
execute if score @s rr_item matches 11 run xp add @s 1000
execute if score @s rr_item matches 12 run give @s minecraft:cobblestone 512
execute if score @s rr_item matches 13 run give @s minecraft:oak_log 256
execute if score @s rr_item matches 14 run give @s minecraft:dirt 512
tellraw @s {"text":"[REWARD] Kamu mendapatkan hadiah BIASA!","color":"white"}
