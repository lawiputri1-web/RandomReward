execute store result score @s rr_item run random value 1..12
execute if score @s rr_item matches 1 run give @s minecraft:diamond 16
execute if score @s rr_item matches 2 run give @s minecraft:diamond_block 4
execute if score @s rr_item matches 3 run give @s minecraft:golden_apple 16
execute if score @s rr_item matches 4 run give @s minecraft:enchanted_golden_apple 2
execute if score @s rr_item matches 5 run give @s minecraft:netherite_ingot 2
execute if score @s rr_item matches 6 run give @s minecraft:diamond_sword 1
execute if score @s rr_item matches 7 run give @s minecraft:diamond_chestplate 1
execute if score @s rr_item matches 8 run give @s minecraft:diamond_pickaxe 1
execute if score @s rr_item matches 9 run give @s minecraft:netherrack 64
execute if score @s rr_item matches 10 run give @s minecraft:totem_of_undying 1
execute if score @s rr_item matches 11 run give @s minecraft:beacon 1
execute if score @s rr_item matches 12 run give @s minecraft:experience_bottle 64
tellraw @s {"text":"[REWARD] KAMU MENDAPATKAN HADIAH OP!","color":"yellow","bold":true}
