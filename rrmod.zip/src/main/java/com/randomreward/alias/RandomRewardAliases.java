package com.randomreward.alias;

import com.mojang.brigadier.Command;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.server.command.CommandManager;
import net.minecraft.text.Text;

public class RandomRewardAliases implements ModInitializer {
    @Override
    public void onInitialize() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
            dispatcher.register(CommandManager.literal("rron")
                .requires(source -> source.hasPermissionLevel(2))
                .executes(context -> {
                    int result = context.getSource().getServer().getCommandManager()
                        .getDispatcher().execute("function rr:on", context.getSource());
                    context.getSource().sendFeedback(() -> Text.literal("Random Reward diaktifkan."), false);
                    return result == 0 ? Command.SINGLE_SUCCESS : result;
                }));
            dispatcher.register(CommandManager.literal("rrof")
                .requires(source -> source.hasPermissionLevel(2))
                .executes(context -> {
                    int result = context.getSource().getServer().getCommandManager()
                        .getDispatcher().execute("function rr:off", context.getSource());
                    context.getSource().sendFeedback(() -> Text.literal("Random Reward dimatikan."), false);
                    return result == 0 ? Command.SINGLE_SUCCESS : result;
                }));
        });
    }
}
